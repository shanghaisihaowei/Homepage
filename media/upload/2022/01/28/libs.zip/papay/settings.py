

DEBUG = True  # 调试为True,上线改为False

MODE = "sandbox" if DEBUG else 'live'

CLIENT_ID = "Aa2i1zDVOPFuNnO_aicXJhVQtBQUDgAlXd3Za_w3lRkGFajzMsh7vycG2M5g8XS-34hRdmRg8c-80A3p"

CLIENT_SECRET = "EId4dJbMPRAi9kUv3tRFgEFWv5DUwU990ZYMLYssQA-W39DsWdcUXg8C5m1Gwl17FTCafw5vHa5DR6MX"