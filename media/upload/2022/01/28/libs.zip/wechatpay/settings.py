




URL = 'https://api.mch.weixin.qq.com/pay/unifiedorder'  # 微信扫码支付接口

KET = 'fryVACZjzPSDmtpkO7yWJlcQcyQKp8LN'

APPID = 'wx9cd695adb4d76810'

MCH_ID = '1615404335'


ORDER_URL = "https://api.mch.weixin.qq.com/pay/orderquery"  # 统一订单查询接口

